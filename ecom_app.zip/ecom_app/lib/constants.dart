
import 'package:flutter/material.dart';

// const kcontectColor = Color.fromARGB(255, 220, 212, 202);
// const kprimaryColor = Color.fromARGB(255, 192, 83, 20);

const kcontectColor = Color(0xffF5F5F5);
const kprimaryColor = Color(0xffff660e);

 const Color scaffoldBg = Color(0xff252734);

 const Color bgLight1 = Color(0xff333646);

 const Color bgLight2 = Color(0xff424657);

 const Color textFieldBg = Color(0xffC8C9CE);

 const Color hintDark = Color(0xff666874);

 const Color yellowSecondary = Color(0xffFFC25C);

 const Color yellowPrimary = Color(0xffFFAF29);

 const Color whitePrimary = Color(0xffEAEAEB);

 const Color whiteSecondary = Color(0xffC8C9CE);