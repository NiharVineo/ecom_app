class Category {
  String title;
  String image;
  
  Category({
    required this.title, 
    required this.image
  });
}

final List<Category> categoriesList = [
  Category(title: "all", image: "images/all.png"),
  Category(title: "Shoes", image: "images/shoes.png"),
  Category(title: "Beauty", image: "images/beauty.png"),
  Category(title: "women's\nFashion", image: "images/image1.png"),
  Category(title: "Jewelry", image: "images/jewelry.png"),
  Category(title: "men's Fashion", image: "images/men.png"),
];