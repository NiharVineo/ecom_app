import 'package:ecom_app/constants.dart';
import 'package:ecom_app/models/product_model.dart';
import 'package:flutter/material.dart';

class ItemsDetails extends StatelessWidget {
  final Product product;
  const ItemsDetails({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
      Text(
        product.title, 
        style: const TextStyle(
          fontSize: 25, 
          fontWeight: FontWeight.w800
          ),
        ),
      const SizedBox(height: 10,),
      Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
            Text(
              "\$${product.price}",
              style: const TextStyle(
                fontSize: 25,
                fontWeight: FontWeight.w800
                ),
              ),
            const SizedBox(width: 10,),
            Row(
              children: [
                Container(
                  width: 55,
                  height: 25,
                  decoration: BoxDecoration(
                    color: kprimaryColor,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  alignment: Alignment.center,
                  padding: const EdgeInsets.symmetric(horizontal: 5),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.star, 
                        color: Colors.white, 
                        size: 15,
                      ),
                      const SizedBox(width: 3,),
                      Text(
                        product.rate.toString(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                  ],)
                ),
                const SizedBox(width: 5,),
                Text(
                  product.review,
                  style: const TextStyle(
                    fontSize: 15,
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
          ],
          ),
          const Spacer(),
          Text.rich(
            TextSpan(
              children: [
                const TextSpan(
                  text: "Seller: ",
                  style: TextStyle(
                    fontSize: 16,
                  ),
                ),
                TextSpan(
                  text: product.seller,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      
    ],);
  }
}