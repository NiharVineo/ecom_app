import 'package:ecom_app/models/category.dart';
import 'package:ecom_app/models/product_model.dart';
import 'package:ecom_app/screens/Home/Widget/home_app_bar.dart';
import 'package:ecom_app/screens/Home/Widget/image_slider.dart';
import 'package:ecom_app/screens/Home/Widget/product_card.dart';
import 'package:ecom_app/screens/Home/Widget/search_bar.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int currentSlider = 0;
  int selectedIndex = 0;
  @override
  Widget build(BuildContext context) {
    List<List<Product>> selectedCategories = [
      all, 
      shoes, 
      beauty,
      womenFashion,
      jewelry,
      menFashion,
      ];

    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView (
        child: Padding( 
          padding: const EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 35,),

              //Custom app bar
              //const CustomAppBar(),

              const SizedBox(height: 20,),

              //Search bar

              const MySearchBar(),

              const SizedBox(height: 20,),

              ImageSlider(CurrentSlide: currentSlider,onChange: (value) {
                setState(() {
                  currentSlider = value;
                });
                },
              ),

              const SizedBox(height: 20,),

              SizedBox(
                height: 130,
                child: ListView.builder(
                  itemCount: categoriesList.length,
                  scrollDirection: Axis.horizontal,
                  //itemCount: categories.length,
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          selectedIndex = index;
                        });
                      },

                      child: Container(
                        padding: const EdgeInsets.all(5),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(15),
                          color : selectedIndex == index 
                            ? Colors.blue
                            : Colors.transparent,
                        ),
                        child: Column(
                          children: [
                            Container(
                              height: 65,
                              width: 65,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                  image: AssetImage(categoriesList[index].image),
                                  fit: BoxFit.cover,
                                ),
                              ),
                              // child: Image.asset(
                              //   categories[index].image,
                              //   fit: BoxFit.cover,
                              // ),
                            ),
                            const SizedBox(height: 5,),
                            Text(categoriesList[index].title,
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                },
                ),
              ),

              const Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                    Text("Special For You",
                    style: TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                  "See all",
                  style: TextStyle(
                    fontWeight: FontWeight.w500,
                    fontSize: 16,
                    color: Colors.black54,
                    ),
                  ),
                  //SizedBox(width: 10,)
                ],
              ),

              //for shopping items

              GridView.builder(
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 0.78,
                  crossAxisSpacing: 20,
                  mainAxisSpacing: 20,
                  ), 
                itemCount: selectedCategories[selectedIndex].length,
                itemBuilder: (context, index) {
                  return ProductCard(
                    product: selectedCategories[selectedIndex][index],
                  );
                },
              ),
            ], 
          ),
        )
      )
    );
  }
}

