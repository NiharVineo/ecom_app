import 'dart:async';

import 'package:ecom_app/screens/nav_bar_screen.dart';
import 'package:flutter/material.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  startTimer() {
    Timer(const Duration(seconds: 3), () {
      
         Navigator.push(context, MaterialPageRoute(builder: (c) => const BottomNavBar()));
      
      
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    startTimer();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold
    (
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container (
            height: 300,
            width: 250,
            child: Image.asset(
              "images/e_com_logo.png",
              fit: BoxFit.cover,
              height: size.height,
              width: size.width,
              ),
            ),
          const Text(
          'E Commerce App',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 40,
            fontWeight: FontWeight.bold
          ),
        ),
        ]
      ),
    );
  }
}